"""Active 1Point3Acres guided practice.

Current topic: Graphs and Search.
Current question: Friend Graph with Timeline (Friend / Unfriend Events).
Read pointacresmemory.md before continuing.
"""

# Question 1: Friend Graph with Timeline (Friend / Unfriend Events)
# Source: 03 Graphs and Search (11).pdf
# Difficulty: Hard
# Main question first; follow-ups come after the main solution is tested.
#
# Main question:
# Given n people and friendship events of the form
# (time, person_a, person_b, "friend"), return the earliest time when all
# people are connected in one friend group. Return -1 if that never happens.
#
# Example:
# n = 3
# events = [(1, 0, 1, "friend"), (5, 1, 2, "friend")]
# expected result: 5
#
# Follow-ups from the PDF:
# - Follow-ups 1/2: explain deletion limits and answer a connectivity query
#   with friend/unfriend events. Inputs include start, target, and query_time.
#   Example: n=3, events=[(1,0,1,"friend"), (2,1,2,"friend"),
#                          (3,1,2,"unfriend")].
#   Query start=0, target=2: at time 2 -> True; at time 3 -> False.
# - Follow-up 3: report group counts after each event (friends only).
#   Example: n=3, friend 0-1, friend 1-2 -> counts [2, 1].
# - Follow-up 4: answer historical connectivity queries without unfriending,
#   using union timestamps; implementation pending.

# INTERVIEW NOTES
# Ordinary Union-Find supports merging groups, but it cannot undo a merge
# when an edge is removed. Removing one edge can split a connected component,
# and the parent links do not preserve enough information to reconstruct that
# split. Rollback Union-Find is an advanced offline alternative.
#
# BRUTE-FORCE INTERVIEW WORDING
# "I sort the E events by time, which costs O(E log E), so I process them
# chronologically. For each distinct timestamp, I replay the events up to that
# time, rebuild the active graph, and run BFS to check connectivity. BFS costs
# O(N + E), and repeating that for T timestamps gives O(E log E +
# T * (N + E)) time. Space is O(N + E) because I reuse the graph, visited
# set, and queue instead of storing a separate graph for every timestamp."
#
# from collections import deque provides the FIFO queue used by BFS.

from collections import deque
#main code helper
class Unionfind:
    def __init__(self, n):
        self.parent = list(range(n))
        self.size = [1] * n
        self.groups = n
        
        # Follow-up 4: record when each parent link formed so queries can
        # distinguish connections that existed at query time from later ones.
        self.linked_time = [0]*n


    def find(self,x):
        if self.parent[x] == x:
            return x

        while self.parent[x] != x:
            x = self.parent[x]

        return x # because we at root by this time


    # Follow-up 4 extension: time is the friendship event timestamp.
    # It lets us record when the new parent link became active for past queries.
    def union(self,a,b,time):
        roota = self.find(a)
        rootb = self.find(b)

        if roota == rootb:
            return False

        if self.size[roota] < self.size[rootb]:
            roota, rootb = rootb, roota

        
        self.size[roota] += self.size[rootb]
        self.parent[rootb] = roota
        # Follow-up 4: rootb acquired parent roota at this event time.
        self.linked_time[rootb] = time
        # Why the entries differ:
        # - Size focuses on roota: its group gained rootb's members.
        # - BOTH parent and link time focus on rootb:
        #   parent[rootb] = roota records WHO became B's parent: A.
        #   linked_time[rootb] = time records WHEN B acquired that parent.
        #   These are two facts about the same new B-to-A parent link.
        # - Roota acquired no new parent here, so its link time stays unchanged.
        # - Link time is an event timestamp, not a sum of timestamps.

        self.groups -=1

        return True


    # Follow-up 4: were people a and b connected at query time t?
    def connected_at(self, a, b, t):
        if a == b:
            return True

        while self.parent[a] != a and self.linked_time[a] <= t:
            pass


def earliest_all_connected(n, events):
    """Return the earliest event time when all people are connected."""
    # TODO: Build this yourself through the guided interview process.
    if n<=1:
        return 0

    # Time: sorting costs O(E log E). With union by size and no path
    # compression, each union costs O(log N), so the total is
    # O(E log E + E log N).
    # Space: Union-Find stores parent, size, and group data for N people: O(N).
    events.sort(key = lambda e: e[0])
    uf = Unionfind(n)

    for event in events:
        time,A,B, kind = event
        if kind == 'friend':
            uf.union(A,B,time)
            if uf.groups == 1:
                return time


    return -1



#follow up 2 
# start and target are person IDs: BFS starts at start and looks for target.
def connected(graph, start, target):
    if start == target:
        return True

    q = deque([start])
    seen = {start}
    while q:
        node = q.popleft()
        if node == target:
            return True
        for nb in graph[node]:
            if nb not in seen:
                seen.add(nb)
                q.append(nb)

    return False

def connected_with_unfriends(n, events, start, target, query_time):
    if start == target:
        return True

    events.sort(key = lambda e: e[0])
    graph = [set() for _ in range(n)]
    for event in events:
        time,A,B, kind = event
        if time > query_time:
            break
        if kind == 'friend':
            graph[A].add(B)
            graph[B].add(A)

        elif kind == 'unfriend':
            graph[A].discard(B)
            graph[B].discard(A)


    # After replaying events through query_time, run BFS once for this query.
    # Time: O(E log E) sorting + O(E) replay + O(N + E) BFS,
    # totaling O(E log E + N + E) per query, with no event-count multiplier
    # on BFS. E is the number of events; active edges are at most E.
    # Space: O(N + E) for the graph, BFS queue/seen, and sorting workspace.
    # Return a Boolean for the query's start/target, rather than an event time.
    return connected(graph, start, target)


# Follow-up 3: group counts after friend events only; reuse Unionfind.
def group_counts_after_events(n, events):
    # 1. Sort events by timestamp.
    # 2. Create Unionfind(n) and an empty counts list.
    # 3. Loop through events and unpack time, A, B, and kind.
    # 4. For each friend event, merge A and B using union.
    # 5. Append uf.groups after each friend event, even if no merge occurred.
    # 6. Return counts after the loop.
    if n==0:
        return []

    events.sort(key = lambda e: e[0])
    uf = Unionfind(n)
    counts = []
    for event in events:
        time,A,B, kind = event
        if kind == 'friend':
            uf.union(A,B,time)
            counts.append(uf.groups)

    return counts





# Follow-up 4: Were A and B connected at time t? (friends only)
# Return True or False for a historical connectivity query.
# Example: n=3, events=[(1,0,1,"friend"), (5,1,2,"friend")].
# Query start=0, target=2, time=2 -> False; time=5 -> True.
# Extend Unionfind with link_time: record when a root is attached to a parent.
# Keep union by size WITHOUT path compression so those timed links survive.
# The query helper checks the newest link on the path between both people.
# We will implement the helper changes first, then the query driver and tests.


def connected_at_time(n, events, start, target, query_time):
    # Outer function for follow-up 4 (friend events only).
    # 1. Create Unionfind(n).
    # 2. Process friend events in time order, passing event time into union.
    # 3. Return uf.connected_at(start, target, query_time).
    # The class method uses parent and linked_time to answer the past query.
    pass


if __name__ == "__main__":
    # Example test to activate after the guided implementation:
    n = 3
    events = [(1, 0, 1, "friend"), (5, 1, 2, "friend")]
    assert earliest_all_connected(n, events) == 5


    n = 4
    events = [(1, 0, 1, "friend"), (5, 2, 3, "friend")]
    assert earliest_all_connected(n, events) == -1


    n = 1
    events = []
    assert earliest_all_connected(n, events) == 0


    # Follow-up 2: ask whether two people are connected at the query time.
    n = 4
    events = [
        (1, 0, 1, "friend"),
        (2, 1, 2, "friend"),
        (3, 1, 2, "unfriend"),
        (4, 2, 3, "friend"),
        (5, 1, 2, "friend"),
    ]
    assert connected_with_unfriends(n, events, 0, 2, 2) is True
    assert connected_with_unfriends(n, events, 0, 2, 3) is False
    assert connected_with_unfriends(n, events, 0, 3, 5) is True
    assert connected_with_unfriends(n, [], 0, 3, 0) is False
    assert connected_with_unfriends(n, [], 1, 1, 0) is True


    # Follow-up 3 (friends only): three people start in three groups.
    # The first friendship leaves two groups; the second leaves one.
    assert group_counts_after_events(
        3, [(1, 0, 1, "friend"), (5, 1, 2, "friend")]
    ) == [2, 1]
