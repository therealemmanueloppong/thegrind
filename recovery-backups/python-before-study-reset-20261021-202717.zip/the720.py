"""Emmanuel's completed solutions, with comments for revision.

Only user implementations and required shared node classes belong here.
Tests and book comparisons are kept separately in the720_checks.py.
"""

from collections import Counter


# =============================================================================
# October 16, 2026 | Day 1 | PDF Q46 | LC 71 | Simplify Path
# =============================================================================
class SimplifyPathSolution:
    def simplifyPath(self, path: str) -> str:
        """Return the canonical form of an absolute Unix path.

        A single dot means the current directory; two dots mean the parent.
        Repeated slashes count as one. Names such as '...' are ordinary names.
        The result starts with '/', with no trailing slash unless it is '/'.

        Examples from the PDF:
            '/home/' -> '/home'
            '/home/user/Documents/../Pictures' -> '/home/user/Pictures'
        """
        # Break the path at slashes; repeated or boundary slashes create empty parts.
        paths =  path.split('/')
        # Keep the folder names that remain in the simplified path, in order.
        stack = []

        # Read each path component from left to right.
        for p in paths:
            # A parent-directory marker cancels the most recently kept folder.
            if p == '..':
                # Only remove a folder when one exists; root has no parent to remove.
                if stack:
                    # Remove the last folder name, moving one level toward root.
                    stack.pop()

            # Empty parts come from extra slashes; a single dot means stay where we are.
            elif not p or p == '.':
                # Neither case changes the kept folders, so move to the next part.
                continue

            # All other components, including three dots, are ordinary names.
            else:
                # Keep this folder as the new final folder in the path.
                stack.append(p)


        # Every absolute canonical path must begin at root with one slash.
        base = '/'
        # Put exactly one slash between the remaining folder names.
        fullp = '/'.join(stack)
        # Add the leading slash; an empty folder list naturally produces root alone.
        return base + fullp


# =============================================================================
# Shared tree-node definition
# =============================================================================
class TreeNode:
    def __init__(self, val=0, left=None, right=None):
        # Store this tree node's value; flattening must keep the same node objects.
        self.val = val
        # Remember the left child, or None if that branch is absent.
        self.left = left
        # Remember the right child; after flattening this link leads to the next node.
        self.right = right


# =============================================================================
# October 16, 2026 | Day 1 | PDF Q47 | LC 114 | Flatten Binary Tree to Linked List
# =============================================================================
class FlattenTreeSolution:
    def flatten(self, root: TreeNode | None) -> None:
        """Modify the tree in place into a chain in preorder traversal order.

        Use the existing TreeNode objects. Every left pointer becomes None;
        right pointers connect the nodes in the resulting chain.
        This method does not return a new tree.

        Example from the PDF (tree input is shown in level order):
            root = [1, 2, 5, 3, 4, None, 6]
            right-pointer chain: 1 -> 2 -> 3 -> 4 -> 5 -> 6
            every left pointer: None
        """
        # An empty tree has no nodes or links to rearrange.
        if not root:
            # Stop without creating or returning a different tree.
            return None

        #preorder
        # The root is the first node waiting for a preorder visit.
        stack = [root]
        # No node has been visited yet, so there is no previous chain node.
        prev = None
        # Keep visiting until there are no waiting nodes left.
        while stack:
            # Take the most recently stored node as the next visit.
            curr = stack.pop()
            # This version can push missing children; detect those None entries here.
            if not curr:
                # Skip a missing child before trying to read its links or update prev.
                continue
            # Only connect a predecessor after a real earlier node has been visited.
            if prev:
                # Append the current visit to the chain by changing the previous right link.
                prev.right = curr
                # Erase the previous node's old left branch so the result is a right-only chain.
                prev.left = None
            # Remember this real node for the next visit; keep this OUTSIDE the if prev guard.
            prev = curr
            # Save the right child first, so it waits underneath the left child.
            stack.append(curr.right)
            # Save the left child last, so the next pop visits it before the right side.
            stack.append(curr.left)


# =============================================================================
# Shared linked-list-node definition
# =============================================================================
class ListNode:
    def __init__(self, val=0, next=None):
        # Store the node's value; reordering must not change this value.
        self.val = val
        # Remember the next node, or None to mark the end of the list.
        self.next = next


# =============================================================================
# October 16, 2026 | Day 1 | PDF Q48 | LC 143 | Reorder List
# =============================================================================
class ReorderListSolution:
    def reorderList(self, head: ListNode | None) -> None:
        """Reorder the existing linked-list nodes in place.

        Required order: L0 -> Ln -> L1 -> Ln-1 -> L2 -> Ln-2 -> ...
        Do not change node values. This method does not return a new list.

        Examples from the PDF:
            1 -> 2 -> 3 -> 4       becomes 1 -> 4 -> 2 -> 3
            1 -> 2 -> 3 -> 4 -> 5  becomes 1 -> 5 -> 2 -> 4 -> 3
        """
        # An empty list or a single node is already in its required order.
        if not head or not head.next:
            # Leave the list unchanged and return no node; the caller still keeps head.
            return  None

        # Store references to every original node so back nodes can be taken with pop.
        stack = []
        # Start the collection walk at the first node without moving the caller's head.
        curr = head
        # Collect nodes until the walk has passed the original tail.
        while curr:
            # Store the node itself, not just its value, because we must reconnect original nodes.
            stack.append(curr)
            # Advance the collection walk; this eventually makes curr None and ends this loop.
            curr = curr.next

        # AFTER the collection loop, reset the walking reference to the front of the list.
        curr = head
        # Form one front/back pair per iteration; an odd middle node is left for the end.
        for i in range(len(stack)//2):
            # Take the next unused node from the original back of the list.
            lastnode = stack.pop()
            # SAVE the original next front node BEFORE overwriting curr.next.
            nextnode = curr.next
            # Connect the current front node to the selected back node.
            curr.next = lastnode
            # Reconnect that back node to the saved front remainder.
            lastnode.next = nextnode
            # Advance the front reference to the saved node for the next pair.
            curr = nextnode

        # AFTER the whole for loop, cut the final old link to prevent a cycle or self-link.
        curr.next = None


# =============================================================================
# October 16, 2026 | Day 1 | PDF Q49 | LC 150 | Evaluate Reverse Polish Notation
# =============================================================================
class ReversePolishNotationSolution:
    def evalRPN(self, tokens: list[str]) -> int:
        """Evaluate a valid expression written with operands before operators.

        Operators are '+', '-', '*', and '/'. Division truncates toward zero.
        The input is valid and never requires division by zero.

        Examples from the PDF:
            ['2', '1', '+', '3', '*'] -> 9   ((2 + 1) * 3)
            ['4', '13', '5', '/', '+'] -> 6 (4 + (13 / 5))
        """
        # Keep numbers and completed subexpression results that are waiting for another operation.
        stack = []
        
        # Read whole string items from left to right, including multi-digit and negative numbers.
        for c in tokens:
            # A sign consumes two waiting values; a valid input guarantees they exist.
            if c in '+-*/':
                # Pop the more recent value FIRST: it is the RIGHT side of subtraction or division.
                b = stack.pop()
                # Pop the earlier value SECOND: it is the LEFT side, so the operation is a op b.
                a = stack.pop()

                # Only the branch matching this sign will run; the separate checks are mutually exclusive.
                if c== '+':
                    # Put the sum back so a later sign can use it as one value.
                    stack.append(a+b)

                # Subtraction needs the original left-to-right operand order.
                if c== '-':
                    # Subtract the later value from the earlier one, then keep the result.
                    stack.append(a-b)


                # Recognize multiplication separately from addition.
                if c== '*':
                    # Multiply the two popped values and keep their product.
                    stack.append(a*b)

                # Division also uses a divided by b, rather than reversing the popped values.
                if c== '/':
                    # Convert the quotient to int to discard its fraction toward zero, including negative results.
                    stack.append(int(a/b))

            # This belongs to the OUTER sign check and handles complete number strings.
            else:
                # Convert this entire item once and store it separately; do not combine different items into digits.
                stack.append(int(c))


        # AFTER the for loop, return the one final integer; a zero answer still occupies one stack entry.
        return stack[0]


# =============================================================================
# October 17, 2026 | Day 2 | PDF Q50 | LC 155 | Min Stack
# =============================================================================
class MinStack:
    def __init__(self):
        # Store the actual numbers; the last list position is the top of the stack.
        self.stack = []
        # Store one minimum per number: entry i is the minimum through stack position i.
        self.minstack = []

    def push(self, val: int) -> None:
        # Add the new number at the top; val is a value, not an index.
        self.stack.append(val)
        # The first value is its own minimum; otherwise compare it with the previous minimum.
        currmin = val if not self.minstack else min(val, self.minstack[-1])
        # Record a minimum for EVERY push, even duplicates, so both lists stay aligned.
        self.minstack.append(currmin)

    def pop(self) -> None:
        # Remove the most recently added number; calls are guaranteed to have a number available.
        self.stack.pop()
        # Remove its matching minimum entry, exposing the minimum before that number was pushed.
        self.minstack.pop()

    def top(self) -> int:
        # Index -1 reads the top value without removing it.
        return self.stack[-1]

    def getMin(self) -> int:
        # Read the current minimum directly, without searching through the values.
        return self.minstack[-1]


# =============================================================================
# October 17, 2026 | Day 2 | PDF Q51 | LC 173 | Binary Search Tree Iterator
# =============================================================================
class BSTIterator:
    """Iterate over the in-order traversal of a binary search tree.

    The first next() returns the smallest value. Calls to next() are valid.
    Follow-up: average O(1) time for next/hasNext and O(h) memory,
    where h is the tree height.
    """

    def __init__(self, root: TreeNode | None):
        """Initialize an iterator positioned before the first value."""
        # Keep waiting NODE objects, including their child links, rather than just their numeric values.
        self.stack = []
        # Use curr to walk from the root without changing the tree or the caller's root reference.
        curr = root
        # Continue while curr refers to a real node; None means this leftward path has ended.
        while curr:
            # Save this node to visit after its smaller left descendants.
            self.stack.append(curr)
            # Walk to the left child, where smaller values are found.
            curr = curr.left

    def next(self) -> int:
        """Advance and return the next value."""
        # Take the smallest waiting node; next() is guaranteed to be called only when one exists.
        node = self.stack.pop()
        # After visiting this node, prepare its right subtree; its smallest value is on its left edge.
        curr = node.right
        # Continue while curr refers to a real node; None means this leftward path has ended.
        while curr:
            # Save this node to visit after its smaller left descendants.
            self.stack.append(curr)
            # Walk to the left child, where smaller values are found.
            curr = curr.left

        # Return this visit's number, not the node object; the stack is ready for the next call.
        return node.val

    def hasNext(self) -> bool:
        """Return whether another value remains."""
        # Report whether any nodes are waiting, without popping or advancing the iterator.
        return len(self.stack) != 0


# =============================================================================
# October 17, 2026 | Day 2 | PDF Q52 | LC 227 | Basic Calculator II
# =============================================================================
class BasicCalculatorIISolution:
    def calculate(self, s: str) -> int:
        """Evaluate a valid expression with nonnegative integers, spaces, and + - * /.

        Integer division truncates toward zero. Do not use eval() or another
        built-in function that evaluates mathematical expression strings.

        Examples from the PDF:
            '3+2*2' -> 7
            ' 3/2 ' -> 1
            ' 3+5 / 2 ' -> 5
        """
        # Keep signed terms; multiplication and division will replace the most recent term.
        stack = []
        # Start building the first number from zero; num holds a value, not a digit position.
        num = 0
        # Remember the operator BEFORE the number being built; the first number is treated as positive.
        sign = '+'

        # i is the character INDEX; character is the one-character text at that position.
        for i, character in enumerate(s):
            # Build numbers only from digits; spaces and operators are not converted to integers.
            if character.isdigit():
                # Shift the existing digits left and add the new digit: 12 followed by 3 becomes 123.
                num = num * 10 + int(character)

            # An operator or the final character finishes a number; the end check also handles trailing spaces.
            if character in '+-*/' or i == len(s) - 1:
                # Use the REMEMBERED operator for num, not the character that just ended it.
                if sign == '+':
                    # Keep this number as a positive term for the final addition.
                    stack.append(num)
                # A subtraction contributes a negative term to the final sum.
                elif sign == '-':
                    # Store the negative value so adding the terms later performs the subtraction.
                    stack.append(-num)
                # Resolve multiplication now, before the final addition of terms.
                elif sign == '*':
                    # Replace the most recent term with its product; earlier terms stay unchanged.
                    stack.append(stack.pop() * num)
                # Resolve division now, using the previous term divided by the current number.
                elif sign == '/':
                    # int discards the fraction toward zero; for example -7/2 becomes -3, not -4.
                    stack.append(int(stack.pop() / num))

                # AFTER the operator branches, reset the number so the next digits start fresh.
                num = 0
                # Remember the new operator for the NEXT number; at the end of the string it will not be used again.
                sign = character

        # AFTER the whole loop, add the signed terms after all multiplication and division are resolved.
        answer = sum(stack)
        # Return the final integer once every input character has been processed.
        return answer


# =============================================================================
# October 17, 2026 | Day 2 | PDF Q53 | LC 255 | Verify Preorder Sequence in Binary Search Tree
# =============================================================================
class VerifyPreorderBSTSolution:
    def verifyPreorder(self, preorder: list[int]) -> bool:
        """Return whether these unique integers can be the preorder of a BST.

        Examples from the PDF:
            [5, 2, 1, 3, 6] -> True
            [5, 2, 6, 1, 3] -> False

        Follow-up: use only constant extra space.
        """
        # Keep ancestor VALUES on the current path; the last entry is the most recent ancestor.
        stack = []
        # No lower cutoff applies initially, so a first value of any allowed size can be accepted.
        lower_bound = float('-inf')

        # Read each VALUE in the proposed visiting order; val is not its index.
        for val in preorder:
            # After entering an ancestor's right subtree, returning below that ancestor is forbidden.
            if val < lower_bound:
                # Stop immediately: this value violates a required BST boundary.
                return False

            # Move past all smaller ancestors; check the stack is nonempty before reading its last entry.
            while stack and val > stack[-1]:
                # Save each ancestor we pass as the cutoff; the last pop gives the strongest lower limit.
                lower_bound = stack.pop()

            # AFTER the while loop, remember this current value as an ancestor for later visits.
            stack.append(val)

        # OUTSIDE both loops: every value passed the checks, so the entire sequence is valid.
        return True


# =============================================================================
# October 18, 2026 | Day 3 | PDF Q54 | LC 316 | Remove Duplicate Letters
# O(n) time; O(26) auxiliary space for lowercase English letters.
# =============================================================================
class RemoveDuplicateLettersSolution:
    def removeDuplicateLetters(self, s: str) -> str:
        """Keep each distinct letter exactly once, preserving the kept letters' order.

        Among all valid results, return the smallest in dictionary order.
        Input contains lowercase English letters.

        Examples:
            "bcabc" -> "abc"
            "cbacdcbc" -> "acdb"
        """
        # Keep the chosen LETTERS in their current result order; the last entry can be reconsidered.
        stack = []
        # Track exactly the letters currently in stack, so each distinct letter appears only once.
        seen = set()
        # Count all occurrences first; as we read, these counts will represent occurrences still ahead.
        counts = Counter(s)
        # Read each LETTER from left to right; c is a character value, not an index.
        for c in s:
            # We have reached this occurrence, so subtract it before checking what remains later.
            counts[c]-=1
            # If this letter is already chosen, keeping it again would create a duplicate.
            if c in seen:
                # Skip the rest of this iteration, while retaining the updated remaining count.
                continue

            # Remove a larger last letter only when it can be chosen again later; check nonempty before indexing.
            while stack and c < stack[-1] and counts[stack[-1]] > 0:
                # Save the letter being removed; a smaller current letter can now take an earlier position.
                removed = stack.pop()
                # Keep seen consistent with stack, allowing this removed letter to be chosen at a later occurrence.
                seen.discard(removed)

            # AFTER all safe removals, add the current letter once to the result.
            stack.append(c)
            # Mark it chosen only AFTER appending it, so its later duplicates will be skipped.
            seen.add(c)

        # AFTER the whole for loop, join the chosen letters into the required string.
        return ''.join(stack)
