"""Completed and reviewed 1Point3Acres solutions.

Question 1 is being archived in the same order used during practice:
problem, examples, brute force, optimal helpers, main solution, follow-ups,
and tests. Follow-up 3 remains pending until it is implemented and tested.
"""

# ============================================================================
# QUESTION 1: Friend Graph with Timeline (Friend / Unfriend Events)
# ============================================================================
# Source: 03 Graphs and Search (11).pdf
# Difficulty: Hard
#
# Problem:
# Given n people and friendship events of the form
# (time, person_a, person_b, "friend"), return the earliest time when all
# people are connected in one friend group. Return -1 if that never happens.
#
# Main example:
# n = 3
# events = [(1, 0, 1, "friend"), (5, 1, 2, "friend")]
# expected result: 5
#
# Why 5: person 0 connects to 1 at time 1, and person 2 joins that group at
# time 5. Only then are all three people connected.

# ----------------------------------------------------------------------------
# BRUTE FORCE: interview explanation
# ----------------------------------------------------------------------------
# "I sort the E events by time, which costs O(E log E), so I process them
# chronologically. For each distinct timestamp, I replay the events up to that
# time, rebuild the active graph, and run BFS to check whether everyone is
# connected. BFS costs O(N + E), and repeating that for T timestamps gives
# O(E log E + T * (N + E)) time. Space is O(N + E) because I reuse the graph,
# visited set, and queue instead of storing a separate graph for every time."
#
# ----------------------------------------------------------------------------
# OPTIMAL BASE SOLUTION: Union-Find
# ----------------------------------------------------------------------------
# Union-Find merges groups efficiently, so it is appropriate when friendships
# only appear. Ordinary Union-Find cannot undo a merge when an edge is removed.
#
# Time: sorting costs O(E log E). This implementation uses union by size but
# no path compression, so each union costs O(log N). Total: O(E log E + E log N).
# Space: O(N) for parent, size, and groups.

from collections import deque


class Unionfind:
    def __init__(self, n):
        self.parent = list(range(n))
        self.size = [1] * n
        self.groups = n

    def find(self, x):
        while self.parent[x] != x:
            x = self.parent[x]
        return x

    def union(self, a, b):
        roota = self.find(a)
        rootb = self.find(b)

        if roota == rootb:
            return False

        if self.size[roota] < self.size[rootb]:
            roota, rootb = rootb, roota

        self.parent[rootb] = roota
        self.size[roota] += self.size[rootb]
        self.groups -= 1
        return True


def earliest_all_connected(n, events):
    """Return the earliest event time when all people are connected."""
    if n <= 1:
        return 0

    events.sort(key=lambda event: event[0])
    uf = Unionfind(n)

    for time, person_a, person_b, kind in events:
        if kind == "friend":
            uf.union(person_a, person_b)
            if uf.groups == 1:
                return time

    return -1


# ----------------------------------------------------------------------------
# FOLLOW-UP 2: Friend and unfriend events
# ----------------------------------------------------------------------------
# Ordinary Union-Find cannot undo a merge. Removing one edge can split a
# connected component, but the parent links do not preserve enough information
# to reconstruct that split. Rollback Union-Find is an advanced offline option.
# For this simpler version, maintain the active graph and run BFS.
#
# Follow-up example:
# n = 4
# events = [
#     (1, 0, 1, "friend"),
#     (2, 1, 2, "friend"),
#     (3, 1, 2, "unfriend"),
#     (4, 2, 3, "friend"),
#     (5, 1, 2, "friend"),
# ]
# expected result: 5
#
# Time for this implementation: O(E log E + E * (N + E)). We sort once, then
# run BFS after every event because the connectivity check is inside the event
# loop. If we checked only once per distinct timestamp, the multiplier would be
# T instead of E. Space: O(N + E) for the active graph, queue, and seen set.


def connected(graph, n):
    if n <= 1:
        return True

    # n is the total number of people; 0 is the ID of the starting person.
    queue = deque([0])
    seen = {0}

    while queue:
        person = queue.popleft()
        for neighbor in graph[person]:
            if neighbor not in seen:
                seen.add(neighbor)
                queue.append(neighbor)

    return len(seen) == n


def earliest_all_connected_with_unfriend(n, events):
    if n <= 1:
        return 0

    events.sort(key=lambda event: event[0])
    graph = [set() for _ in range(n)]

    for time, person_a, person_b, kind in events:
        if kind == "friend":
            graph[person_a].add(person_b)
            graph[person_b].add(person_a)
        elif kind == "unfriend":
            graph[person_a].discard(person_b)
            graph[person_b].discard(person_a)

        if connected(graph, n):
            return time

    return -1


# ----------------------------------------------------------------------------
# FOLLOW-UP 3: Report the number of groups after each event
# ----------------------------------------------------------------------------
# Example: friend 0-1, friend 1-2, unfriend 1-2 -> [2, 1, 2].
# Implementation is pending and will be appended after it is guided, tested,
# and reviewed in pointacres.py.


# ----------------------------------------------------------------------------
# REVIEWED TESTS
# ----------------------------------------------------------------------------
if __name__ == "__main__":
    assert earliest_all_connected(
        3, [(1, 0, 1, "friend"), (5, 1, 2, "friend")]
    ) == 5

    assert earliest_all_connected(
        4, [(1, 0, 1, "friend"), (5, 2, 3, "friend")]
    ) == -1

    assert earliest_all_connected(1, []) == 0

    assert earliest_all_connected_with_unfriend(
        4,
        [
            (1, 0, 1, "friend"),
            (2, 1, 2, "friend"),
            (3, 1, 2, "unfriend"),
            (4, 2, 3, "friend"),
            (5, 1, 2, "friend"),
        ],
    ) == 5
